<?php

namespace App\Controllers;

use App\Models\EmpruntModel;
use App\Models\LivreModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class MouvementController extends BaseController
{
    private const ROUTE_LIVRES = '/livres/';
    private const MESSAGE_LIVRE_INTROUVABLE = 'Livre introuvable.';

    private LivreModel $livreModel;
    private EmpruntModel $empruntModel;

    public function __construct()
    {
        $this->livreModel = new LivreModel();
        $this->empruntModel = new EmpruntModel();
    }

    public function loan(int $id)
    {
        $livre = $this->livreModel->find($id);

        if ($livre === null) {
            throw PageNotFoundException::forPageNotFound(self::MESSAGE_LIVRE_INTROUVABLE);
        }

        if (($livre['statut'] ?? 'disponible') !== 'disponible') {
            return redirect()->to(self::ROUTE_LIVRES . $id)->with('error', 'Ce livre n est pas disponible.');
        }

        $rules = [
            'nom_emprunteur' => 'required|min_length[2]|max_length[255]',
        ];

        $messages = [
            'nom_emprunteur' => [
                'required' => "Le nom de l emprunteur est requis.",
                'min_length' => "Le nom de l emprunteur doit contenir au moins 2 caracteres.",
            ],
        ];

        if (! $this->validateData($this->request->getPost(), $rules, $messages)) {
            return redirect()->to(self::ROUTE_LIVRES . $id)->withInput()->with('validation', $this->validator);
        }

        $nomEmprunteur = trim((string) $this->request->getPost('nom_emprunteur'));

        $this->empruntModel->insert([
            'livre_id' => $id,
            'nom_emprunteur' => $nomEmprunteur,
            'date_emprunt' => date('Y-m-d'),
            'date_retour' => null,
        ]);

        $this->livreModel->update($id, [
            'statut' => 'prete',
        ]);

        return redirect()->to(self::ROUTE_LIVRES . $id)->with('success', 'Pret enregistre avec succes.');
    }

    public function returnBook(int $id)
    {
        $livre = $this->livreModel->find($id);

        if ($livre === null) {
            throw PageNotFoundException::forPageNotFound(self::MESSAGE_LIVRE_INTROUVABLE);
        }

        $empruntActif = $this->empruntModel
            ->where('livre_id', $id)
            ->where('date_retour', null)
            ->orderBy('date_emprunt', 'DESC')
            ->first();

        if ($empruntActif === null) {
            return redirect()->to(self::ROUTE_LIVRES . $id)->with('error', 'Aucun emprunt actif trouve pour ce livre.');
        }

        $this->empruntModel->update($empruntActif['id'], [
            'date_retour' => date('Y-m-d'),
        ]);

        $this->livreModel->update($id, [
            'statut' => 'disponible',
        ]);

        return redirect()->to(self::ROUTE_LIVRES . $id)->with('success', 'Retour enregistre avec succes.');
    }
}
