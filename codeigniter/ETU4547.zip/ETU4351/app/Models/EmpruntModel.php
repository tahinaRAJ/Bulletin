<?php

namespace App\Models;

use CodeIgniter\Model;

class EmpruntModel extends Model
{
    protected $table = 'emprunts';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $useAutoIncrement = true;
    protected $protectFields = true;

    protected $allowedFields = [
        'livre_id',
        'nom_emprunteur',
        'date_emprunt',
        'date_retour',
    ];

    public function getDernierEmpruntPourLivre(int $livreId): ?array
    {
        $resultat = $this->where('livre_id', $livreId)
            ->orderBy('date_emprunt', 'DESC')
            ->first();

        return $resultat === null ? null : $resultat;
    }
}
