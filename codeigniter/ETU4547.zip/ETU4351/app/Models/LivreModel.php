<?php

namespace App\Models;

use CodeIgniter\Model;
use InvalidArgumentException;

class LivreModel extends Model
{
    protected $table = 'livres';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $useAutoIncrement = true;
    protected $protectFields = true;

    protected $allowedFields = [
        'titre',
        'auteur',
        'isbn',
        'annee_publication',
        'categorie',
        'resume',
        'couverture',
        'statut',
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'titre' => 'required|min_length[3]',
        'auteur' => 'required',
        'isbn' => 'required|is_unique[livres.isbn,id,{id}]',
        'annee_publication' => 'required|integer',
    ];

    protected $validationMessages = [
        'titre' => [
            'required' => 'Le titre est obligatoire.',
            'min_length' => 'Le titre doit contenir au moins 3 caracteres.',
        ],
        'auteur' => [
            'required' => "L'auteur est obligatoire.",
        ],
        'isbn' => [
            'required' => "L'ISBN est obligatoire.",
            'is_unique' => "L'ISBN existe deja en base de donnees.",
        ],
        'annee_publication' => [
            'required' => "L'annee de publication est obligatoire.",
            'integer' => "L'annee de publication doit etre un nombre entier.",
        ],
    ];

    protected $beforeInsert = ['validerAnneePublicationAvantEcriture'];
    protected $beforeUpdate = ['validerAnneePublicationAvantEcriture'];

    public function anneePublicationValide(int $annee): bool
    {
        return $annee <= (int) date('Y');
    }

    public function rechercher(?string $motCle = null, ?string $categorie = null): array
    {
        $builder = $this->builder();
        $builder->select('*');

        $motCle = trim((string) $motCle);
        $categorie = trim((string) $categorie);

        if ($motCle !== '') {
            $builder->like('titre', $motCle);
        }

        if ($categorie !== '') {
            $builder->where('categorie', $categorie);
        }

        $builder->orderBy('titre', 'ASC');

        return $builder->get()->getResultArray();
    }

    public function getLivresPagines(int $parPage = 10): array
    {
        return $this->orderBy('titre', 'ASC')->paginate($parPage);
    }

    protected function validerAnneePublicationAvantEcriture(array $data): array
    {
        if (! isset($data['data']['annee_publication'])) {
            return $data;
        }

        $annee = (int) $data['data']['annee_publication'];

        if (! $this->anneePublicationValide($annee)) {
            throw new InvalidArgumentException("L'annee de publication ne peut pas etre dans le futur.");
        }

        return $data;
    }
}
