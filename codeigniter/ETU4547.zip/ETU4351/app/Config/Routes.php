<?php

use CodeIgniter\Router\RouteCollection;


/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'LibraryController::index');

$routes->get('/livres', 'LibraryController::index');
$routes->get('/livres/new', 'LibraryController::new');
$routes->post('/livres', 'LibraryController::store');
$routes->get('/livres/(:num)', 'LibraryController::show/$1');
$routes->post('/livres/(:num)/loan', 'MouvementController::loan/$1');
$routes->post('/livres/(:num)/return', 'MouvementController::returnBook/$1');
$routes->post('/livres/(:num)/delete', 'LibraryController::delete/$1');
